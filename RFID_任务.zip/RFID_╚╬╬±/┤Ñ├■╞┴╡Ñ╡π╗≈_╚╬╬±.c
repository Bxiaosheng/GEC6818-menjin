#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>
#include <errno.h>
#include <linux/input.h>  

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>


#include <stdio.h>//printf、scanf
#include <termios.h>
#include <sys/types.h>//open
#include <sys/stat.h>//open
#include <fcntl.h>//open
#include <string.h>//bzero
#include "uart.h"


#if 1
	#define DEBUG printf("file is: %s, function is: %s, line is: %d\n\n", __FILE__, __FUNCTION__, __LINE__);
#else
	#define DEBUG
#endif




//定义相关变量
int touch_lcdfd = -1, x = 0, y = 0;
//定义一个结构体用以存放输入事件数据
struct input_event buf;

//函数声明
void touch_lcd(void);


//定义全局变量
int lcd_fd, bmp_fd, ret;
int *lcd_fp = NULL;


//编译命令：arm-linux-gcc    mmap_show_bmp.c
//执行命令：./a.out  123.bmp


//处理屏幕设备
int lcd_init(void)
{	
	//打开屏幕
	lcd_fd = open("/dev/fb0", O_RDWR);
	if(lcd_fd == -1)
	{
		perror("open LCD failed");
		return -1;
	}
	
	//建立内存映射
	lcd_fp = mmap(NULL, 800*480*4, PROT_WRITE, MAP_SHARED, lcd_fd, 0);
	if(lcd_fp == NULL)
	{
		perror("mmap failed\n");
		return -1;
	}
}

//打开图片文件
//show_bmp("./456.bmp");
int show_bmp(char *pathname)
{	
	//打开图片，利用open函数打开指定路径的图片文件
	bmp_fd = open( pathname, O_RDWR);
	if(bmp_fd == -1)
	{
		perror("open bmp failed");
		return -1;
	}
	
	//跳过前54个字节BMP格式头
	lseek(bmp_fd, 54, SEEK_SET);
	
	//定义数组存放图片的真实数据（BGR为3个字节）
	char bmp_buf[800*480*3]={0};
	
	//读取真实颜色数据，由于BMP图片真实的格式为BGR，即一个像素点为3个字节，所以一张800*480大小的图片的总字节数为800*480*3
	ret = read(bmp_fd, bmp_buf, sizeof(bmp_buf));	//read函数是每次读取一个字节，读取指定的总字节数
	if(ret == -1)
	{
		perror("read bmp failed");
		return -1;
	}
	
	int i, j;
	int bmp_cmp_buf[800*480] = {0};
	//作24位图的BGR 转换成 屏幕的ARGB
	for(i=0,j=0; i<800*480; i++, j+=3)
	{
						//bmp_buf[0] = 一个字节：B， bmp_buf[012] = 一个字节：BGR,  一行像素点：BGR BGR BGR BGR BGR BGR
		bmp_cmp_buf[i] = 0x00<<24 | (bmp_buf[j+2] << 16) | (bmp_buf[j+1] << 8) | (bmp_buf[j+0] << 0);
	
	}
	
	int x, y;
	
	int bmp_up_buf[800*480] = {0};
	//作图片的上下颠倒处理
	for(y=0; y<480; y++)
	{
		for(x=0; x<800; x++)
		{
			bmp_up_buf[800*y+x] = bmp_cmp_buf[800*(479-y)+x];
		}	
	}
	
	//把数据写入映射内存（屏幕）
	for(y=0; y<480; y++)
	{
		for(x=0; x<800; x++)
		{
			lcd_fp[800*y+x] = bmp_up_buf[800*y+x];
		}
	}
	
	//关闭图片文件
	close(bmp_fd);
}


void password_fun(void)
{		
	printf("请输入正确密码\n");
	
	//假设密码为“1234”
	/*利用static关键字修饰局部变量，使得它的生命周期与程序一样长，且局部变量只定义一次，变量空间里的数据会被保留，而非每次进入函数重新定义变量*/
	static int  i = 0;	
	static int  arr[4] = {0,0,0,0};
	static int  password[4] = {1,2,3,4};
	
	while(1)
	{
		//读触摸屏的触摸数值,拿取x\y轴坐标值数据
		touch_lcd();	//调用一次函数，获取一次触摸数据
		
		printf("单次点击坐标点为：(%d , %d)\n", x, y);
		
		//坐标判断
		if(x>0 && x < 200 && y >0 && y<100)
		{
			arr[i] = 1;
			printf("arr[%d] == %d\n", i, arr[i]);
			i++;
		}
		if(x>200 && x < 400 && y >0 && y<100)
		{
			arr[i] = 2;
			printf("arr[%d] == %d\n", i, arr[i]);
			i++;
		}
		if(x>400 && x < 600 && y >0 && y<100)
		{
			arr[i] = 3;
			printf("arr[%d] == %d\n", i, arr[i]);
			i++;
		}
		if(x>600 && x < 800 && y >0 && y<100)
		{
			arr[i] = 4;
			printf("arr[%d] == %d\n", i, arr[i]);
			i++;
		}
		
		//判断是否输入四位数
		if(i==4)
		{
			if(arr[0]==1 && arr[1]==2 && arr[2]==3 && arr[3]==4 )
			{
				printf("密码输入正确\n");
				
				//显示一张正确的图片
			
				//退出循环
				break;
			}
			else 
			{
				i = 0;
				memset(arr, 0, sizeof(arr));
				printf("密码输入错误\n");
			}
		}
		//判断密码   int  password[6] = {1,2,3,4,6,7};
		//if(arr[0]==1 && arr[1]==2 && arr[1]==3 && arr[1]==4 )
		/*			//通过求得的数组大小除以数组里的一个元素的大小，就可以得到数组有元素个数
		for(j=0; j<( sizeof(password)/sizeof(password[0])); j++)
		{
			//只要有一个数字不对，清空整个数组，下标置零，且提示密码错误
			if( arr[j] != password[j])
			{
				i = 0;
				memset(arr, 0, sizeof(arr));
				printf("input password failed.\n");
			}
		}
		*/
		
	}
}

int pic_up(char *pathname, int* pic_up_fd)
{	
	int ret=0;
	int line=0;
	int block=0;
	int i=0, j=0, k=0;
	int bmp_fd=0;
	
	char bmp_buf[480*800*3];
	int mi_buf[480*800];	
	int temp_buf[480*800];	
	bzero(mi_buf,sizeof(mi_buf));
	bzero(bmp_buf,sizeof(bmp_buf));
	bzero(temp_buf,sizeof(temp_buf));

	bmp_fd = open(pathname , O_RDONLY);//1、打开BMP格式图片
	if(bmp_fd == -1)
	{
		printf("pic_up(), open bmp failed\n");
		return -1;
	}

	ret = lseek(bmp_fd, 54 , SEEK_SET);//2、跳过bmp图片的前54个位置
	if(ret == -1)
	{
		perror("pic_up(), lseek bmp failed\n");		
		return -1;
	}

	ret = read(bmp_fd , bmp_buf , sizeof(bmp_buf)); //4、取读图片像素
	if(ret == -1)
	{
		printf("pic_up(), read bmp failed\n");	
		return -1;
	}
	
	close(bmp_fd);//5、关闭图片

	for(i=0, j=0 ; i<800*480 ; i++, j+=3)//6、24bits 转 32bits控制变量
	{
		temp_buf[i] = bmp_buf[j+2]<<16 | bmp_buf[j+1]<<8 | bmp_buf[j] ;
	}

	for(line=0 ; line <=480 ;line++)//7、解决图片上下颠倒问题
	{
		for(i=0; i<=800 ; i++)
		mi_buf[800*line + i] = temp_buf[ (479-line)*800 + i ];
	}

	//8、特殊动画“向上飞入”效果算法
	for(i=479; i>=0; i--)
	{
		for(j=0; j<800; j++)
		{
			pic_up_fd[800*i+j] = mi_buf[800*i+j];	
		}
		usleep(500);
	} 	
	
	return 0;
}

//编译命令：arm-linux-gcc 触摸屏单点击_任务.c  uart.c

int main()
{
	//打开屏幕设备
	lcd_init();
	
	//打开触摸屏
	touch_lcdfd = open( "/dev/input/event0" , O_RDONLY);
	if(touch_lcdfd < 0)
	{
		perror("open fd error");
		return -1;
	}
	
	//打开串口接口
	int fd_tty;
	fd_tty = open("/dev/ttySAC1", O_RDWR);
	if(fd_tty == -1)
	{
		printf("open serial fail!");
		return -1;
	}
	
	//显示密码键盘图片
	//show_bmp("./password.bmp");
	
	//特效显示
	pic_up("./password.bmp", lcd_fp);
	usleep(1000);	//延时1000微秒 == 1毫秒
	//pic_up("./123.bmp", lcd_fp);
	
	//判断输入密码函数
	password_fun();

{	
	/*读设备信息，配置读卡芯片：这里是配置读卡器的*/
	//配置串口接口
	init_tty(fd_tty);
	
	//：这里是配置读卡器读取卡片信息的
	send_A_command(fd_tty);//请求

	//防碰撞
	int card_id=0;
	card_id = send_B_command(fd_tty);
	
	//获取到了卡号（只作信息的获取）
	printf("\nIC id: %#X\n", card_id);

	//判断卡号是否为 标记的卡号 
	if(card_id == 0XAD9CEF53)
	{
		//提示:这是正确的卡号
		printf("OK\n");
		
		//显示一张图片提示
		
	}
	send_C_command(fd_tty, card_id);//选择，判断序列号是否完整
}	
	
	printf("进入系统\n");
	
	//做以下任务
	while(1)
	{
		//读触摸屏的触摸数值,拿取x\y轴坐标值数据
		touch_lcd();	//调用一次函数，获取一次触摸数据
		
		printf("单次点击坐标点为：(%d , %d)\n", x, y);
		
		if(x>0 && x < 100 && y >0 && y<100)
		{
			printf("点击了左上角\n");
			//显示指定路径的图片
			//show_bmp("./456.bmp");
		}
		if(x>0 && x < 100 && y >380 && y<480)
		{
			printf("点击了左下角\n");
		}
		if(x>700 && x < 800 && y >0 && y<100)
		{
			printf("点击了右上角\n");
		}
		if(x>700 && x < 800 && y >380 && y<480)
		{
			printf("点击了右下角\n");
		}
	}
	
	//解除映射内存
	munmap(lcd_fp, 800*480*4);	//内存空间800*480*4总字节
	//关闭屏幕
	close(lcd_fd);
	
	return 0;
}

void touch_lcd(void)
{
	while(1)
	{
		//读取触摸屏接口，拿触摸屏数据，读取出来的数据是一个结构体，放在buf里。
		read(touch_lcdfd, &buf, sizeof(buf));
		
		//如果是绝对值坐标，且是x轴的绝对坐标
		if( (buf.type == EV_ABS) && (buf.code == ABS_X) )
		{
			//如果你的开发板的屏幕的边是黑色的就用以下获取坐标的代码：
			x = buf.value*800/1024;
			
			
			//如果你的开发板的屏幕的边是蓝色
			//x = buf.value;
		}
		
		//如果是绝对值坐标，且是y轴的绝对坐标
		if( (buf.type == EV_ABS) && (buf.code == ABS_Y) )
		{
			//如果你的开发板的屏幕的边是黑色的就用以下获取坐标的代码：
			y = buf.value*480/600;
			
			//如果你的开发板的屏幕的边是蓝色
			//y = buf.value;
		}
		
		//如果是触摸屏触摸事件，且为松开状态
		if((buf.code==BTN_TOUCH) && (buf.value==0))
		{
			//退出循环
			break;	
		}
	}
}